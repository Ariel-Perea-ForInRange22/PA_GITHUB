# Consumer-Loan-Assistant
This is java based projects. In this project we calculate the interest paid by user , how many EMI remaining and many more.
