package com.company;

class loanassistantTest {

}